const color = prompt("Введите цвет")

switch (color) {
    case "Красный":
        console.log("Ехать нельзя");
    break;
    case "Желтый":
        console.log("Предупреждение");
    break;
    case "Зеленный":
        console.log("Ехать можно");
    break;
}
