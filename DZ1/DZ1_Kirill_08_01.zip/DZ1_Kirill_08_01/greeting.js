const name = prompt("Введите имя")

console.log("Привет " + name)