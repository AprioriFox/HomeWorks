for (let sym = "*"; sym.length <= 7; sym = sym + "*"){
    console.log(sym);
}
